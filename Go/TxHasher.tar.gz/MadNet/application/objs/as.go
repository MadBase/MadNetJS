package objs

import (
	"encoding/hex"
	"errors"

	"github.com/MadHive/MadNet/application/objs/atomicswap"
	mdefs "github.com/MadHive/MadNet/application/objs/capn"
	"github.com/MadHive/MadNet/utils"
	capnp "zombiezen.com/go/capnproto2"
)

// AtomicSwap is an atomic swap object based on a time lock hash
type AtomicSwap struct {
	ASPreImage *ASPreImage `json:"ASPreImage"`
	TxHash     string      `json:"TxHash"`
}

// MarshalBinary takes the AtomicSwap object and returns the canonical
// byte slice
func (b *AtomicSwap) MarshalBinary() ([]byte, error) {
	if b == nil {
		return nil, errors.New("not initialized")
	}
	bc, err := b.MarshalCapn(nil)
	if err != nil {
		return nil, err
	}
	return atomicswap.Marshal(bc)
}

// MarshalCapn marshals the object into its capnproto definition
func (b *AtomicSwap) MarshalCapn(seg *capnp.Segment) (mdefs.AtomicSwap, error) {
	if b == nil {
		return mdefs.AtomicSwap{}, errors.New("not initialized")
	}
	var bc mdefs.AtomicSwap
	if seg == nil {
		_, seg, err := capnp.NewMessage(capnp.SingleSegment(nil))
		if err != nil {
			return bc, err
		}
		tmp, err := mdefs.NewRootAtomicSwap(seg)
		if err != nil {
			return bc, err
		}
		bc = tmp
	} else {
		tmp, err := mdefs.NewAtomicSwap(seg)
		if err != nil {
			return bc, err
		}
		bc = tmp
	}
	bt, err := b.ASPreImage.MarshalCapn(seg)
	if err != nil {
		return bc, err
	}
	txHash, err := hex.DecodeString(b.TxHash)
	if err != nil {
		return bc, err
	}
	if err := bc.SetTxHash(utils.CopySlice(txHash)); err != nil {
		return bc, err
	}
	if err := bc.SetASPreImage(bt); err != nil {
		return bc, err
	}
	return bc, nil
}

// PreHash returns the PreHash of the object
func (b *AtomicSwap) PreHash() (string, error) {
	return b.ASPreImage.PreHash()
}

// UTXOID returns the UTXOID of the object
func (b *AtomicSwap) UTXOID() (string, error) {
	return MakeUTXOID(b.TxHash, b.ASPreImage.TXOutIdx)
}

// TXOutIdx returns the TXOutIdx of the object
func (b *AtomicSwap) TXOutIdx() uint32 {
	return b.ASPreImage.TXOutIdx
}

// SetTxHash sets the TxHash of the object
func (b *AtomicSwap) SetTxHash(txHash string) {
	b.TxHash = txHash
}
