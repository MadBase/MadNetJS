package objs

import (
	"encoding/hex"

	"github.com/MadHive/MadNet/application/objs/aspreimage"
	mdefs "github.com/MadHive/MadNet/application/objs/capn"
	"github.com/MadHive/MadNet/application/objs/uint256"
	"github.com/MadHive/MadNet/crypto"
	capnp "zombiezen.com/go/capnproto2"
)

// CopySlice returns a copy of a passed byte slice.
func CopySlice(v []byte) []byte {
	out := make([]byte, len(v))
	copy(out, v)
	return out
}

// ASPreImage holds the values required for an AtomicSwap object
type ASPreImage struct {
	ChainID  uint32 `json:"ChainID"`
	Value    string `json:"Value"`
	TXOutIdx uint32 `json:"TXOutIdx"`
	IssuedAt uint32 `json:"IssuedAt"`
	Exp      uint32 `json:"Exp"`
	Owner    string `json:"Owner"`
	Fee      string `json:"Fee"`
}

// MarshalBinary takes the ASPreImage object and returns the canonical
// byte slice
func (b *ASPreImage) MarshalBinary() ([]byte, error) {
	bc, err := b.MarshalCapn(nil)
	if err != nil {
		return nil, err
	}
	return aspreimage.Marshal(bc)
}

// MarshalCapn marshals the object into its capnproto definition
func (b *ASPreImage) MarshalCapn(seg *capnp.Segment) (mdefs.ASPreImage, error) {
	var bc mdefs.ASPreImage
	if seg == nil {
		_, seg, err := capnp.NewMessage(capnp.SingleSegment(nil))
		if err != nil {
			return bc, err
		}
		tmp, err := mdefs.NewRootASPreImage(seg)
		if err != nil {
			return bc, err
		}
		bc = tmp
	} else {
		tmp, err := mdefs.NewASPreImage(seg)
		if err != nil {
			return bc, err
		}
		bc = tmp
	}
	ownerHex, err := hex.DecodeString(b.Owner)
	if err != nil {
		return bc, err
	}
	if err := bc.SetOwner(ownerHex); err != nil {
		return bc, nil
	}
	bc.SetChainID(b.ChainID)
	bc.SetTXOutIdx(b.TXOutIdx)
	bc.SetIssuedAt(b.IssuedAt)
	bc.SetExp(b.Exp)
	{
		feeBytes, err := hex.DecodeString(b.Value)
		if err != nil {
			return bc, err
		}
		feeO, err := uint256.Uint256FromBytes(feeBytes)
		if err != nil {
			return bc, err
		}
		u32array, err := feeO.ToUint32Array()
		if err != nil {
			return bc, err
		}
		bc.SetValue(u32array[0])
		bc.SetValue1(u32array[1])
		bc.SetValue2(u32array[2])
		bc.SetValue3(u32array[3])
		bc.SetValue4(u32array[4])
		bc.SetValue5(u32array[5])
		bc.SetValue6(u32array[6])
		bc.SetValue7(u32array[7])
	}
	{
		feeBytes, err := hex.DecodeString(b.Fee)
		if err != nil {
			return bc, err
		}
		feeO, err := uint256.Uint256FromBytes(feeBytes)
		if err != nil {
			return bc, err
		}
		u32array, err := feeO.ToUint32Array()
		if err != nil {
			return bc, err
		}
		bc.SetFee0(u32array[0])
		bc.SetFee1(u32array[1])
		bc.SetFee2(u32array[2])
		bc.SetFee3(u32array[3])
		bc.SetFee4(u32array[4])
		bc.SetFee5(u32array[5])
		bc.SetFee6(u32array[6])
		bc.SetFee7(u32array[7])
	}
	return bc, nil
}

// PreHash returns the PreHash of the object
func (b *ASPreImage) PreHash() (string, error) {
	msg, err := b.MarshalBinary()
	if err != nil {
		return "", err
	}
	hsh := crypto.Hasher(msg)
	preHash := hsh
	return hex.EncodeToString(preHash), nil
}
