package aspreimage

import (
	"errors"

	mdefs "github.com/MadHive/MadNet/application/objs/capn"
	"github.com/MadHive/MadNet/utils"
	capnp "zombiezen.com/go/capnproto2"
)

// Marshal will marshal a ASPreImage object.
func Marshal(v mdefs.ASPreImage) ([]byte, error) {
	raw, err := capnp.Canonicalize(v.Struct)
	if err != nil {
		return nil, err
	}
	out := utils.CopySlice(raw)
	return out, nil
}

// Unmarshal will unmarshal the ASPreImage object.
func Unmarshal(data []byte) (mdefs.ASPreImage, error) {
	var err error
	fn := func() (mdefs.ASPreImage, error) {
		defer func() {
			if r := recover(); r != nil {
				err = errors.New("bad serialization")
			}
		}()
		dataCopy := utils.CopySlice(data)
		msg := &capnp.Message{Arena: capnp.SingleSegment(dataCopy)}
		obj, tmp := mdefs.ReadRootASPreImage(msg)
		err = tmp
		return obj, err
	}
	obj, err := fn()
	if err != nil {
		return mdefs.ASPreImage{}, err
	}
	return obj, nil
}
