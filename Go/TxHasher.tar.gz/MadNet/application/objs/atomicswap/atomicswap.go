package atomicswap

import (
	"errors"

	mdefs "github.com/MadHive/MadNet/application/objs/capn"
	"github.com/MadHive/MadNet/utils"
	capnp "zombiezen.com/go/capnproto2"
)

// Marshal will marshal a AtomicSwap object.
func Marshal(v mdefs.AtomicSwap) ([]byte, error) {
	raw, err := capnp.Canonicalize(v.Struct)
	if err != nil {
		return nil, err
	}
	out := utils.CopySlice(raw)
	return out, nil
}

// Unmarshal will unmarshal the AtomicSwap object.
func Unmarshal(data []byte) (mdefs.AtomicSwap, error) {
	var err error
	fn := func() (mdefs.AtomicSwap, error) {
		defer func() {
			if r := recover(); r != nil {
				err = errors.New("bad serialization")
			}
		}()
		dataCopy := utils.CopySlice(data)
		msg := &capnp.Message{Arena: capnp.SingleSegment(dataCopy)}
		obj, tmp := mdefs.ReadRootAtomicSwap(msg)
		err = tmp
		return obj, err
	}
	obj, err := fn()
	if err != nil {
		return mdefs.AtomicSwap{}, err
	}
	return obj, nil
}
