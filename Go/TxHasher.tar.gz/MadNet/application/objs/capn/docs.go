package capn

/*
In order to use the code generation facilities of this package, you must first
install the capnproto toolchain. The directions for this installation may be
found at the following:
https://capnproto.org/install.html
*/
