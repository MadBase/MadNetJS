package objs

import (
	"encoding/hex"

	mdefs "github.com/MadHive/MadNet/application/objs/capn"
	"github.com/MadHive/MadNet/application/objs/datastore"
	capnp "zombiezen.com/go/capnproto2"
)

// DataStore is a datastore UTXO
type DataStore struct {
	DSLinker  *DSLinker `json:"DSLinker"`
	Signature string    `json:"Signature"`
}

// MarshalBinary takes the DataStore object and returns the canonical
// byte slice
func (b *DataStore) MarshalBinary() ([]byte, error) {
	bc, err := b.MarshalCapn(nil)
	if err != nil {
		return nil, err
	}
	return datastore.Marshal(bc)
}

// MarshalCapn marshals the object into its capnproto definition
func (b *DataStore) MarshalCapn(seg *capnp.Segment) (mdefs.DataStore, error) {
	var bc mdefs.DataStore
	if seg == nil {
		_, seg, err := capnp.NewMessage(capnp.SingleSegment(nil))
		if err != nil {
			return bc, err
		}
		tmp, err := mdefs.NewRootDataStore(seg)
		if err != nil {
			return bc, err
		}
		bc = tmp
	} else {
		tmp, err := mdefs.NewDataStore(seg)
		if err != nil {
			return bc, err
		}
		bc = tmp
	}
	seg = bc.Struct.Segment()
	bt, err := b.DSLinker.MarshalCapn(seg)
	if err != nil {
		return bc, err
	}
	if err := bc.SetDSLinker(bt); err != nil {
		return bc, err
	}
	hexSig, err := hex.DecodeString(b.Signature)
	if err != nil {
		return bc, err
	}
	if err := bc.SetSignature(hexSig); err != nil {
		return bc, err
	}
	return bc, nil
}

// PreHash returns the PreHash of the object
func (b *DataStore) PreHash() (string, error) {
	return b.DSLinker.PreHash()
}

// UTXOID returns the UTXOID of the object
func (b *DataStore) UTXOID() (string, error) {
	return b.DSLinker.UTXOID()
}

// TXOutIdx returns the TXOutIdx of the object
func (b *DataStore) TXOutIdx() uint32 {
	return b.DSLinker.TXOutIdx()
}

// SetTxHash sets the TxHash of the object
func (b *DataStore) SetTxHash(txHash string) {
	b.DSLinker.TxHash = txHash
}
