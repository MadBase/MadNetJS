package objs

import (
	"encoding/hex"

	mdefs "github.com/MadHive/MadNet/application/objs/capn"
	"github.com/MadHive/MadNet/application/objs/dslinker"
	capnp "zombiezen.com/go/capnproto2"
)

// DSLinker ...
type DSLinker struct {
	DSPreImage *DSPreImage `json:"DSPreImage"`
	TxHash     string      `json:"TxHash"`
}

// MarshalBinary takes the DSLinker object and returns the canonical
// byte slice
func (b *DSLinker) MarshalBinary() ([]byte, error) {
	bc, err := b.MarshalCapn(nil)
	if err != nil {
		return nil, err
	}
	return dslinker.Marshal(bc)
}

// MarshalCapn marshals the object into its capnproto definition
func (b *DSLinker) MarshalCapn(seg *capnp.Segment) (mdefs.DSLinker, error) {
	var bc mdefs.DSLinker
	if seg == nil {
		_, seg, err := capnp.NewMessage(capnp.SingleSegment(nil))
		if err != nil {
			return bc, err
		}
		tmp, err := mdefs.NewRootDSLinker(seg)
		if err != nil {
			return bc, err
		}
		bc = tmp
	} else {
		tmp, err := mdefs.NewDSLinker(seg)
		if err != nil {
			return bc, err
		}
		bc = tmp
	}
	seg = bc.Struct.Segment()
	bt, err := b.DSPreImage.MarshalCapn(seg)
	if err != nil {
		return bc, err
	}
	if err := bc.SetDSPreImage(bt); err != nil {
		return bc, err
	}
	txHash, err := hex.DecodeString(b.TxHash)
	if err != nil {
		return bc, err
	}
	if err := bc.SetTxHash(txHash); err != nil {
		return bc, err
	}
	return bc, nil
}

// PreHash returns the PreHash of the object
func (b *DSLinker) PreHash() (string, error) {
	return b.DSPreImage.PreHash()
}

// UTXOID returns the UTXOID of the object
func (b *DSLinker) UTXOID() (string, error) {
	return MakeUTXOID(b.TxHash, b.DSPreImage.TXOutIdx)
}

// TXOutIdx returns the TXOutIdx of the object
func (b *DSLinker) TXOutIdx() uint32 {
	return b.DSPreImage.TXOutIdx
}
