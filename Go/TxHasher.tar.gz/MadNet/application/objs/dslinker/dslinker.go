package dslinker

import (
	"errors"

	mdefs "github.com/MadHive/MadNet/application/objs/capn"
	"github.com/MadHive/MadNet/utils"
	capnp "zombiezen.com/go/capnproto2"
)

// Marshal will marshal a DSLinker object.
func Marshal(v mdefs.DSLinker) ([]byte, error) {
	raw, err := capnp.Canonicalize(v.Struct)
	if err != nil {
		return nil, err
	}
	out := utils.CopySlice(raw)
	return out, nil
}

// Unmarshal will unmarshal the DSLinker object.
func Unmarshal(data []byte) (mdefs.DSLinker, error) {
	var err error
	fn := func() (mdefs.DSLinker, error) {
		defer func() {
			if r := recover(); r != nil {
				err = errors.New("bad serialization")
			}
		}()
		dataCopy := utils.CopySlice(data)
		msg := &capnp.Message{Arena: capnp.SingleSegment(dataCopy)}
		obj, tmp := mdefs.ReadRootDSLinker(msg)
		err = tmp
		return obj, err
	}
	obj, err := fn()
	if err != nil {
		return mdefs.DSLinker{}, err
	}
	return obj, nil
}
