package objs

import (
	"encoding/hex"

	mdefs "github.com/MadHive/MadNet/application/objs/capn"
	"github.com/MadHive/MadNet/application/objs/dspreimage"
	"github.com/MadHive/MadNet/application/objs/uint256"
	"github.com/MadHive/MadNet/crypto"
	capnp "zombiezen.com/go/capnproto2"
)

// DSPreImage is a DataStore preimage
type DSPreImage struct {
	ChainID  uint32 `json:"ChainID"`
	Index    string `json:"Index"`
	IssuedAt uint32 `json:"IssuedAt"`
	Deposit  string `json:"Deposit"`
	RawData  string `json:"RawData"`
	TXOutIdx uint32 `json:"TXOutIdx"`
	Owner    string `json:"Owner"`
	Fee      string `json:"Fee"`
}

// MarshalBinary takes the DSPreImage object and returns the canonical
// byte slice
func (b *DSPreImage) MarshalBinary() ([]byte, error) {
	bc, err := b.MarshalCapn(nil)
	if err != nil {
		return nil, err
	}
	return dspreimage.Marshal(bc)
}

// MarshalCapn marshals the object into its capnproto definition
func (b *DSPreImage) MarshalCapn(seg *capnp.Segment) (mdefs.DSPreImage, error) {
	var bc mdefs.DSPreImage
	if seg == nil {
		_, seg, err := capnp.NewMessage(capnp.SingleSegment(nil))
		if err != nil {
			return bc, err
		}
		tmp, err := mdefs.NewRootDSPreImage(seg)
		if err != nil {
			return bc, err
		}
		bc = tmp
	} else {
		tmp, err := mdefs.NewDSPreImage(seg)
		if err != nil {
			return bc, err
		}
		bc = tmp
	}
	index, err := hex.DecodeString(b.Index)
	if err != nil {
		return bc, err
	}
	rawData, err := hex.DecodeString(b.RawData)
	if err != nil {
		return bc, err
	}
	owner, err := hex.DecodeString(b.Owner)
	if err != nil {
		return bc, err
	}
	if err := bc.SetIndex(index); err != nil {
		return bc, err
	}
	if err := bc.SetRawData(rawData); err != nil {
		return bc, err
	}
	if err := bc.SetOwner(owner); err != nil {
		return bc, err
	}
	bc.SetChainID(b.ChainID)
	bc.SetIssuedAt(b.IssuedAt)
	bc.SetTXOutIdx(b.TXOutIdx)
	{
		feeBytes, err := hex.DecodeString(b.Deposit)
		if err != nil {
			return bc, err
		}
		feeO, err := uint256.Uint256FromBytes(feeBytes)
		if err != nil {
			return bc, err
		}
		u32array, err := feeO.ToUint32Array()
		if err != nil {
			return bc, err
		}
		bc.SetDeposit(u32array[0])
		bc.SetDeposit1(u32array[1])
		bc.SetDeposit2(u32array[2])
		bc.SetDeposit3(u32array[3])
		bc.SetDeposit4(u32array[4])
		bc.SetDeposit5(u32array[5])
		bc.SetDeposit6(u32array[6])
		bc.SetDeposit7(u32array[7])
	}
	{
		feeBytes, err := hex.DecodeString(b.Fee)
		if err != nil {
			return bc, err
		}
		feeO, err := uint256.Uint256FromBytes(feeBytes)
		if err != nil {
			return bc, err
		}
		u32array, err := feeO.ToUint32Array()
		if err != nil {
			return bc, err
		}
		bc.SetFee0(u32array[0])
		bc.SetFee1(u32array[1])
		bc.SetFee2(u32array[2])
		bc.SetFee3(u32array[3])
		bc.SetFee4(u32array[4])
		bc.SetFee5(u32array[5])
		bc.SetFee6(u32array[6])
		bc.SetFee7(u32array[7])
	}
	return bc, nil
}

// PreHash returns the PreHash of the object
func (b *DSPreImage) PreHash() (string, error) {
	msg, err := b.MarshalBinary()
	if err != nil {
		return "", err
	}
	hsh := crypto.Hasher(msg)
	return hex.EncodeToString(hsh), nil
}

// RewardDepositEquation allows a reward calculated for cleaning up an expired
// datastore.
func RewardDepositEquation(deposit uint32, dataSize uint32, epochInitial uint32, epochFinal uint32) uint32 {
	remainder := deposit - BaseDepositEquation(dataSize, epochFinal-epochInitial)
	if remainder >= deposit-BaseDepositEquation(dataSize, 0) {
		return dataSize
	}
	if remainder > dataSize {
		return remainder
	}
	return dataSize
}

// BaseDepositEquation specifies a required deposit for a certain amount of
// data to persist for a specified number of epochs.
// TODO: Need to bound the total size of a transaction by 2MB. We should
// require base cost so no one can attack the system by continually writing
// nothing to it. At some point, we may wish to add a quadratic term
// for sufficiently large values of dataSize to discourage large submissions.
func BaseDepositEquation(dataSize uint32, numEpochs uint32) uint32 {
	return dataSize*(2+numEpochs) + 256
}

// NumEpochsEquation returns the number of epochs until expiration
func NumEpochsEquation(dataSize uint32, deposit uint32) uint32 {
	return (((deposit - 256) / dataSize) - 2)
}
