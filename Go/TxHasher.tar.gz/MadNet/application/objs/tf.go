package objs

import (
	"encoding/hex"

	mdefs "github.com/MadHive/MadNet/application/objs/capn"
	"github.com/MadHive/MadNet/application/objs/txfee"
	"github.com/MadHive/MadNet/errorz"
	capnp "zombiezen.com/go/capnproto2"
)

// TxFee stores the transaction fee in a Tx
type TxFee struct {
	TFPreImage *TFPreImage `json:"TFPreImage"`
	TxHash     string      `json:"TxHash"`
}

// MarshalBinary takes the ValueStore object and returns the canonical
// byte slice
func (b *TxFee) MarshalBinary() ([]byte, error) {
	if b == nil {
		return nil, errorz.ErrInvalid{}.New("not initialized")
	}
	bc, err := b.MarshalCapn(nil)
	if err != nil {
		return nil, err
	}
	return txfee.Marshal(bc)
}

// MarshalCapn marshals the object into its capnproto definition
func (b *TxFee) MarshalCapn(seg *capnp.Segment) (mdefs.TxFee, error) {
	if b == nil {
		return mdefs.TxFee{}, errorz.ErrInvalid{}.New("not initialized")
	}
	var bc mdefs.TxFee
	if seg == nil {
		_, seg, err := capnp.NewMessage(capnp.SingleSegment(nil))
		if err != nil {
			return bc, err
		}
		tmp, err := mdefs.NewRootTxFee(seg)
		if err != nil {
			return bc, err
		}
		bc = tmp
	} else {
		tmp, err := mdefs.NewTxFee(seg)
		if err != nil {
			return bc, err
		}
		bc = tmp
	}
	seg = bc.Struct.Segment()
	bt, err := b.TFPreImage.MarshalCapn(seg)
	if err != nil {
		return bc, err
	}
	if err := bc.SetTFPreImage(bt); err != nil {
		return bc, err
	}
	txHash, err := hex.DecodeString(b.TxHash)
	if err != nil {
		return bc, err
	}
	if err := bc.SetTxHash(txHash); err != nil {
		return bc, err
	}
	return bc, nil
}

// PreHash calculates the PreHash of the object
func (b *TxFee) PreHash() (string, error) {
	if b == nil {
		return "", errorz.ErrInvalid{}.New("not initialized")
	}
	return b.TFPreImage.PreHash()
}

// UTXOID calculates the UTXOID of the object
func (b *TxFee) UTXOID() (string, error) {
	utxoID, err := MakeUTXOID(b.TxHash, b.TFPreImage.TXOutIdx)
	if err != nil {
		return "", err
	}
	return utxoID, nil
}

// TXOutIdx returns the TXOutIdx of the object
func (b *TxFee) TXOutIdx() uint32 {
	return b.TFPreImage.TXOutIdx
}

// SetTXOutIdx sets the TXOutIdx of the object
func (b *TxFee) SetTXOutIdx(idx uint32) error {
	if b == nil || b.TFPreImage == nil {
		return errorz.ErrInvalid{}.New("not initialized")
	}
	b.TFPreImage.TXOutIdx = idx
	return nil
}

// SetTxHash sets the TxHash of the object
func (b *TxFee) SetTxHash(txHash string) {
	b.TxHash = txHash
}

// // SetTxHash sets the TxHash of the object
// func (b *TxFee) SetTxHash(txHash []byte) error {
// 	if b == nil || b.TFPreImage == nil {
// 		return errorz.ErrInvalid{}.New("not initialized")
// 	}
// 	if len(txHash) != constants.HashLen {
// 		return errorz.ErrInvalid{}.New("Invalid hash length")
// 	}
// 	b.TxHash = utils.CopySlice(txHash)
// 	return nil
// }

// ChainID returns the ChainID of the object
func (b *TxFee) ChainID() (uint32, error) {
	if b == nil || b.TFPreImage == nil || b.TFPreImage.ChainID == 0 {
		return 0, errorz.ErrInvalid{}.New("not initialized")
	}
	return b.TFPreImage.ChainID, nil
}

// // Fee returns the Fee of the object; Fee should always be nonzero
// func (b *TxFee) Fee() (string, error) {
// 	if b == nil || b.TFPreImage == nil || b.TFPreImage.Fee == nil || b.TFPreImage.Fee.IsZero() {
// 		return nil, errorz.ErrInvalid{}.New("not initialized")
// 	}
// 	return b.TFPreImage.Fee.Clone(), nil
// }

// func (b *TxFee) String() string {
// 	return fmt.Sprintf("{TFPreImage: %v, TxHash: %v, utxoID: %v}", b.TFPreImage.String(), b.TxHash, b.utxoID)
// }
