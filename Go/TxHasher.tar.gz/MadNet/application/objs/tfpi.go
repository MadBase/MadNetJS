package objs

import (
	"encoding/hex"

	mdefs "github.com/MadHive/MadNet/application/objs/capn"
	"github.com/MadHive/MadNet/application/objs/tfpreimage"
	"github.com/MadHive/MadNet/application/objs/uint256"
	"github.com/MadHive/MadNet/crypto"
	"github.com/MadHive/MadNet/errorz"
	capnp "zombiezen.com/go/capnproto2"
)

// TFPreImage is a txfee preimage
type TFPreImage struct {
	ChainID  uint32 `json:"ChainID"`
	TXOutIdx uint32 `json:"TXOutIdx"`
	Fee      string `json:"Fee"`
}

// MarshalBinary takes the TFPreImage object and returns the canonical
// byte slice
func (b *TFPreImage) MarshalBinary() ([]byte, error) {
	if b == nil {
		return nil, errorz.ErrInvalid{}.New("not initialized")
	}
	bc, err := b.MarshalCapn(nil)
	if err != nil {
		return nil, err
	}
	return tfpreimage.Marshal(bc)
}

// MarshalCapn marshals the object into its capnproto definition
func (b *TFPreImage) MarshalCapn(seg *capnp.Segment) (mdefs.TFPreImage, error) {
	if b == nil {
		return mdefs.TFPreImage{}, errorz.ErrInvalid{}.New("not initialized")
	}
	var bc mdefs.TFPreImage
	if seg == nil {
		_, seg, err := capnp.NewMessage(capnp.SingleSegment(nil))
		if err != nil {
			return bc, err
		}
		tmp, err := mdefs.NewRootTFPreImage(seg)
		if err != nil {
			return bc, err
		}
		bc = tmp
	} else {
		tmp, err := mdefs.NewTFPreImage(seg)
		if err != nil {
			return bc, err
		}
		bc = tmp
	}
	bc.SetChainID(b.ChainID)
	feeBytes, err := hex.DecodeString(b.Fee)
	if err != nil {
		return bc, err
	}
	feeO, err := uint256.Uint256FromBytes(feeBytes)
	if err != nil {
		return bc, err
	}
	u32array, err := feeO.ToUint32Array()
	if err != nil {
		return bc, err
	}
	bc.SetFee0(u32array[0])
	bc.SetFee1(u32array[1])
	bc.SetFee2(u32array[2])
	bc.SetFee3(u32array[3])
	bc.SetFee4(u32array[4])
	bc.SetFee5(u32array[5])
	bc.SetFee6(u32array[6])
	bc.SetFee7(u32array[7])
	bc.SetTXOutIdx(b.TXOutIdx)
	return bc, nil
}

// PreHash calculates the PreHash of the object
func (b *TFPreImage) PreHash() (string, error) {
	if b == nil {
		return "", errorz.ErrInvalid{}.New("not initialized")
	}
	msg, err := b.MarshalBinary()
	if err != nil {
		return "", err
	}
	hsh := crypto.Hasher(msg)
	return hex.EncodeToString(hsh), nil
}
