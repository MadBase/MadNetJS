package objs

import (
	"encoding/hex"

	"github.com/MadHive/MadNet/crypto"
	trie "github.com/MadHive/MadNet/memoryTrie"
	"github.com/MadHive/MadNet/sorter"
)

// Tx is a transaction object
type Tx struct {
	Vin  *[]*TXIn  `json:"Vin"`
	Vout *[]*TXOut `json:"Vout"`
}

// TxHash calculates the TxHash of the transaction
func (b *Tx) TxHash() (string, error) {
	keys := [][]byte{}
	values := [][]byte{}
	for _, txIn := range *b.Vin {
		id, err := txIn.UTXOID()
		if err != nil {
			return "", err
		}
		idb, err := hex.DecodeString(id)
		if err != nil {
			return "", err
		}
		keys = append(keys, idb)
		hsh, err := txIn.PreHash()
		if err != nil {
			return "", err
		}
		hshb, err := hex.DecodeString(hsh)
		if err != nil {
			return "", err
		}
		values = append(values, hshb)
	}
	for idx, txOut := range *b.Vout {
		hsh, err := txOut.PreHash()
		if err != nil {
			return "", err
		}
		id, err := MakeUTXOID(hsh, uint32(idx))
		if err != nil {
			return "", err
		}
		idb, err := hex.DecodeString(id)
		if err != nil {
			return "", err
		}
		hshb, err := hex.DecodeString(hsh)
		if err != nil {
			return "", err
		}
		keys = append(keys, idb)
		values = append(values, hshb)
	}
	// new in memory smt
	smt := trie.NewSMT()
	// smt update
	err := sorter.SortKVs(keys, values)
	if err != nil {
		return "", err
	}
	if len(keys) == 0 && len(values) == 0 {
		rootHash := crypto.Hasher([][]byte{}...)
		txHash := rootHash
		return hex.EncodeToString(txHash), nil
	}
	rootHash, err := smt.Update(keys, values)
	if err != nil {
		return "", err
	}
	txHash := rootHash
	return hex.EncodeToString(txHash), nil
}

// SetTxHash calculates the TxHash and sets it on all UTXOs and TXIns
func (b *Tx) SetTxHash() error {
	txHash, err := b.TxHash()
	if err != nil {
		return err
	}
	for _, txIn := range *b.Vin {
		txIn.SetTxHash(txHash)
	}
	for _, txOut := range *b.Vout {
		txOut.SetTxHash(txHash)
	}
	return nil
}
