package objs

import (
	"encoding/hex"

	mdefs "github.com/MadHive/MadNet/application/objs/capn"
	"github.com/MadHive/MadNet/application/objs/txin"
	capnp "zombiezen.com/go/capnproto2"
)

// TXIn is a tx input object that acts as a reference to a UTXO
type TXIn struct {
	TXInLinker *TXInLinker `json:"TXInLinker"`
	Signature  string      `json:"Signature"`
}

// MarshalBinary takes the TXIn object and returns the canonical
// byte slice
func (b *TXIn) MarshalBinary() ([]byte, error) {
	bc, err := b.MarshalCapn(nil)
	if err != nil {
		return nil, err
	}
	return txin.Marshal(bc)
}

// MarshalCapn marshals the object into its capnproto definition
func (b *TXIn) MarshalCapn(seg *capnp.Segment) (mdefs.TXIn, error) {
	var bc mdefs.TXIn
	if seg == nil {
		_, seg, err := capnp.NewMessage(capnp.SingleSegment(nil))
		if err != nil {
			return bc, err
		}
		tmp, err := mdefs.NewRootTXIn(seg)
		if err != nil {
			return bc, err
		}
		bc = tmp
	} else {
		tmp, err := mdefs.NewTXIn(seg)
		if err != nil {
			return bc, err
		}
		bc = tmp
	}
	seg = bc.Struct.Segment()
	bt, err := b.TXInLinker.MarshalCapn(seg)
	if err != nil {
		return bc, err
	}
	if err := bc.SetTXInLinker(bt); err != nil {
		return bc, err
	}
	signature, err := hex.DecodeString(b.Signature)
	if err != nil {
		return bc, err
	}
	if err := bc.SetSignature(signature); err != nil {
		return bc, err
	}
	return bc, nil
}

// PreHash returns the PreHash of the object
func (b *TXIn) PreHash() (string, error) {
	return b.TXInLinker.PreHash()
}

func (b *TXIn) SignValue() ([]byte, error) {
	bb, err := b.TXInLinker.MarshalBinary()
	if err != nil {
		return nil, err
	}
	return bb, nil
}

// UTXOID returns the UTXOID of the object
func (b *TXIn) UTXOID() (string, error) {
	return b.TXInLinker.UTXOID()
}

// SetTxHash sets the TxHash of the TXIn object
func (b *TXIn) SetTxHash(txHash string) {
	b.TXInLinker.SetTxHash(txHash)
}

// ConsumedTxIdx returns the consumed TxIdx
func (b *TXIn) ConsumedTxIdx() uint32 {
	return b.TXInLinker.ConsumedTxIdx()
}

// ConsumedTxHash returns the consumed TxHash
func (b *TXIn) ConsumedTxHash() string {
	return b.TXInLinker.ConsumedTxHash()
}
