package objs

import (
	"encoding/hex"

	mdefs "github.com/MadHive/MadNet/application/objs/capn"
	"github.com/MadHive/MadNet/application/objs/txinlinker"
	"github.com/MadHive/MadNet/utils"
	capnp "zombiezen.com/go/capnproto2"
)

// TXInLinker ...
type TXInLinker struct {
	TXInPreImage *TXInPreImage `json:"TXInPreImage"`
	TxHash       string        `json:"TxHash"`
}

// MarshalBinary takes the TXInLinker object and returns the canonical
// byte slice
func (b *TXInLinker) MarshalBinary() ([]byte, error) {
	bc, err := b.MarshalCapn(nil)
	if err != nil {
		return nil, err
	}
	return txinlinker.Marshal(bc)
}

// MarshalCapn marshals the object into its capnproto definition
func (b *TXInLinker) MarshalCapn(seg *capnp.Segment) (mdefs.TXInLinker, error) {
	var bc mdefs.TXInLinker
	if seg == nil {
		_, seg, err := capnp.NewMessage(capnp.SingleSegment(nil))
		if err != nil {
			return bc, err
		}
		tmp, err := mdefs.NewRootTXInLinker(seg)
		if err != nil {
			return bc, err
		}
		bc = tmp
	} else {
		tmp, err := mdefs.NewTXInLinker(seg)
		if err != nil {
			return bc, err
		}
		bc = tmp
	}
	seg = bc.Struct.Segment()
	bt, err := b.TXInPreImage.MarshalCapn(seg)
	if err != nil {
		return bc, err
	}
	if err := bc.SetTXInPreImage(bt); err != nil {
		return bc, err
	}
	txHash, err := hex.DecodeString(b.TxHash)
	if err != nil {
		return bc, err
	}
	if err := bc.SetTxHash(utils.CopySlice(txHash)); err != nil {
		return bc, err
	}
	return bc, nil
}

// PreHash returns the PreHash of the object
func (b *TXInLinker) PreHash() (string, error) {
	return b.TXInPreImage.PreHash()
}

// UTXOID returns the UTXOID of the object
func (b *TXInLinker) UTXOID() (string, error) {
	return b.TXInPreImage.UTXOID()
}

// SetTxHash sets TxHash
func (b *TXInLinker) SetTxHash(txHash string) {
	b.TxHash = txHash
}

// ConsumedTxIdx returns the consumed TxIdx
func (b *TXInLinker) ConsumedTxIdx() uint32 {
	return b.TXInPreImage.ConsumedTxIdx
}

// ConsumedTxHash returns the consumed TxHash
func (b *TXInLinker) ConsumedTxHash() string {
	return b.TXInPreImage.ConsumedTxHash
}
