package objs

import (
	"encoding/hex"

	mdefs "github.com/MadHive/MadNet/application/objs/capn"
	"github.com/MadHive/MadNet/application/objs/txinpreimage"
	"github.com/MadHive/MadNet/crypto"
	capnp "zombiezen.com/go/capnproto2"
)

// TXInPreImage is the tx input preimage
type TXInPreImage struct {
	ChainID        uint32 `json:"ChainID"`
	ConsumedTxIdx  uint32 `json:"ConsumedTxIdx"`
	ConsumedTxHash string `json:"ConsumedTxHash"`
}

// MarshalBinary takes the TXInPreImage object and returns the canonical
// byte slice
func (b *TXInPreImage) MarshalBinary() ([]byte, error) {
	bc, err := b.MarshalCapn(nil)
	if err != nil {
		return nil, err
	}
	return txinpreimage.Marshal(bc)
}

// MarshalCapn marshals the object into its capnproto definition
func (b *TXInPreImage) MarshalCapn(seg *capnp.Segment) (mdefs.TXInPreImage, error) {
	var bc mdefs.TXInPreImage
	if seg == nil {
		_, seg, err := capnp.NewMessage(capnp.SingleSegment(nil))
		if err != nil {
			return bc, err
		}
		tmp, err := mdefs.NewRootTXInPreImage(seg)
		if err != nil {
			return bc, err
		}
		bc = tmp
	} else {
		tmp, err := mdefs.NewTXInPreImage(seg)
		if err != nil {
			return bc, err
		}
		bc = tmp
	}
	txHash, err := hex.DecodeString(b.ConsumedTxHash)
	if err != nil {
		return bc, err
	}
	if err := bc.SetConsumedTxHash(txHash); err != nil {
		return bc, err
	}
	bc.SetChainID(b.ChainID)
	bc.SetConsumedTxIdx(b.ConsumedTxIdx)
	return bc, nil
}

// PreHash returns the PreHash of the object
func (b *TXInPreImage) PreHash() (string, error) {
	msg, err := b.MarshalBinary()
	if err != nil {
		return "", err
	}
	hsh := crypto.Hasher(msg)
	return hex.EncodeToString(hsh), nil
}

// UTXOID returns the UTXOID of the object
func (b *TXInPreImage) UTXOID() (string, error) {
	return MakeUTXOID(b.ConsumedTxHash, b.ConsumedTxIdx)
}
