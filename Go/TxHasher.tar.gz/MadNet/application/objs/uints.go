package objs

import (
	"encoding/binary"
	"errors"
)

// MarshalInt64 will marshal an int64 object.
func MarshalInt64(v int64) []byte {
	vv := make([]byte, 8)
	binary.BigEndian.PutUint64(vv, uint64(v))
	return vv[:]
}

// UnmarshalInt64 will unmarshal an int64 object.
func UnmarshalInt64(v []byte) (int64, error) {
	if len(v) != 8 {
		return 0, errors.New("")
	}
	vv := int64(binary.BigEndian.Uint64(v))
	return vv, nil
}

// MarshalUint32 will marshal an uint32 object.
func MarshalUint32(v uint32) []byte {
	vv := make([]byte, 4)
	binary.BigEndian.PutUint32(vv, v)
	return vv[:]
}

// UnmarshalUint32 will unmarshal an uint32 object.
func UnmarshalUint32(v []byte) (uint32, error) {
	if len(v) != 4 {
		return 0, errors.New("")
	}
	vv := binary.BigEndian.Uint32(v)
	return vv, nil
}
