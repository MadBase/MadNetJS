package objs

import (
	"encoding/hex"

	"github.com/MadHive/MadNet/constants"
	"github.com/MadHive/MadNet/crypto"
	"github.com/MadHive/MadNet/utils"
)

// MakeUTXOID will create the UTXOID for a utxo given a transaction hash and
// index.
func MakeUTXOID(txHashStr string, idx uint32) (string, error) {
	txHash, err := hex.DecodeString(txHashStr)
	if err != nil {
		return "", err
	}
	if idx == constants.MaxUint32 {
		return txHashStr, nil
	}
	idxBytes := MarshalUint32(idx)
	msg := utils.CopySlice(txHash)
	msg = append(msg, idxBytes...)
	hshb := crypto.Hasher(msg)
	return hex.EncodeToString(hshb), nil
}
