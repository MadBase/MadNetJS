package objs

import (
	"errors"

	mdefs "github.com/MadHive/MadNet/application/objs/capn"
	"github.com/MadHive/MadNet/application/objs/utxo"
	capnp "zombiezen.com/go/capnproto2"
)

// TXOut is a UTXO object
type TXOut struct {
	DataStore  *DataStore  `json:"DataStore,omitempty"`
	ValueStore *ValueStore `json:"ValueStore,omitempty"`
	AtomicSwap *AtomicSwap `json:"AtomicSwap,omitempty"`
	TxFee      *TxFee      `json:"TxFee,omitempty"`
}

// MarshalBinary takes the TXOut object and returns the canonical
// byte slice
func (b *TXOut) MarshalBinary() ([]byte, error) {
	bc, err := b.MarshalCapn(nil)
	if err != nil {
		return nil, err
	}
	return utxo.Marshal(bc)
}

// MarshalCapn marshals the object into its capnproto definition
func (b *TXOut) MarshalCapn(seg *capnp.Segment) (mdefs.TXOut, error) {
	var bc mdefs.TXOut
	if seg == nil {
		_, seg, err := capnp.NewMessage(capnp.SingleSegment(nil))
		if err != nil {
			return bc, err
		}
		tmp, err := mdefs.NewRootTXOut(seg)
		if err != nil {
			return bc, err
		}
		bc = tmp
	} else {
		tmp, err := mdefs.NewTXOut(seg)
		if err != nil {
			return bc, err
		}
		bc = tmp
	}
	seg = bc.Struct.Segment()
	switch {
	case b.HasDataStore():
		ds, err := b.DataStore.MarshalCapn(seg)
		if err != nil {
			return bc, err
		}
		if err := bc.SetDataStore(ds); err != nil {
			return bc, err
		}
	case b.HasValueStore():
		vs, err := b.ValueStore.MarshalCapn(seg)
		if err != nil {
			return bc, err
		}
		if err := bc.SetValueStore(vs); err != nil {
			return bc, err
		}
	case b.HasAtomicSwap():
		as, err := b.AtomicSwap.MarshalCapn(seg)
		if err != nil {
			return bc, err
		}
		if err := bc.SetAtomicSwap(as); err != nil {
			return bc, err
		}
	case b.HasTxFee():
		tf, err := b.TxFee.MarshalCapn(seg)
		if err != nil {
			return bc, err
		}
		if err := bc.SetTxFee(tf); err != nil {
			return bc, err
		}
	default:
		return mdefs.TXOut{}, errors.New("TXOut type not defined in MarshalCapn")
	}
	return bc, nil
}

func (b *TXOut) HasDataStore() bool {
	if b.DataStore != nil {
		return true
	}
	return false
}

func (b *TXOut) HasTxFee() bool {
	if b.TxFee != nil {
		return true
	}
	return false
}

func (b *TXOut) HasValueStore() bool {
	if b.ValueStore != nil {
		return true
	}
	return false
}

func (b *TXOut) HasAtomicSwap() bool {
	if b.AtomicSwap != nil {
		return true
	}
	return false
}

// PreHash returns the PreHash of the object
func (b *TXOut) PreHash() (string, error) {
	switch {
	case b.HasDataStore():
		obj := b.DataStore
		return obj.PreHash()
	case b.HasValueStore():
		obj := b.ValueStore
		return obj.PreHash()
	case b.HasAtomicSwap():
		obj := b.AtomicSwap
		return obj.PreHash()
	case b.HasTxFee():
		obj := b.TxFee
		return obj.PreHash()
	default:
		return "", errors.New("TXOut type not defined in PreHash")
	}
}

// UTXOID returns the UTXOID of the object
func (b *TXOut) UTXOID() (string, error) {
	switch {
	case b.HasDataStore():
		obj := b.DataStore
		return obj.UTXOID()
	case b.HasValueStore():
		obj := b.ValueStore
		return obj.UTXOID()
	case b.HasAtomicSwap():
		obj := b.AtomicSwap
		return obj.UTXOID()
	case b.HasTxFee():
		obj := b.TxFee
		return obj.UTXOID()
	default:
		return "", errors.New("TXOut type not defined in UTXOID")
	}
}

// TXOutIdx returns the TXOutIdx of the object
func (b *TXOut) TXOutIdx() uint32 {
	switch {
	case b.HasDataStore():
		obj := b.DataStore
		return obj.TXOutIdx()
	case b.HasValueStore():
		obj := b.ValueStore
		return obj.TXOutIdx()
	case b.HasAtomicSwap():
		obj := b.AtomicSwap
		return obj.TXOutIdx()
	case b.HasTxFee():
		obj := b.TxFee
		return obj.TXOutIdx()
	default:
		panic("TXOut type not defined in TXOutIdx")
	}
}

// SetTxHash sets the txHash of the object
func (b *TXOut) SetTxHash(txHash string) {
	switch {
	case b.HasDataStore():
		obj := b.DataStore
		obj.SetTxHash(txHash)
	case b.HasValueStore():
		obj := b.ValueStore
		obj.SetTxHash(txHash)
	case b.HasAtomicSwap():
		obj := b.AtomicSwap
		obj.SetTxHash(txHash)
	case b.HasTxFee():
		obj := b.TxFee
		obj.SetTxHash(txHash)
	default:
		panic("TXOut type not defined in UTXOID")
	}
}
