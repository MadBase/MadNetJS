package valuestore

import (
	"errors"

	mdefs "github.com/MadHive/MadNet/application/objs/capn"
	capnp "zombiezen.com/go/capnproto2"
)

// Marshal will marshal a ValueStore object.
func Marshal(v mdefs.ValueStore) ([]byte, error) {
	raw, err := capnp.Canonicalize(v.Struct)
	if err != nil {
		return nil, err
	}
	out := make([]byte, len(raw))
	copy(out, raw)
	return out, nil
}

// Unmarshal will unmarshal the ValueStore object.
func Unmarshal(data []byte) (mdefs.ValueStore, error) {
	var err error
	fn := func() (mdefs.ValueStore, error) {
		defer func() {
			if r := recover(); r != nil {
				err = errors.New("bad serialization")
			}
		}()
		dataCopy := make([]byte, len(data))
		copy(dataCopy, data)
		msg := &capnp.Message{Arena: capnp.SingleSegment(dataCopy)}
		obj, tmp := mdefs.ReadRootValueStore(msg)
		err = tmp
		return obj, err
	}
	obj, err := fn()
	if err != nil {
		return mdefs.ValueStore{}, err
	}
	return obj, nil
}
