package objs

import (
	"encoding/hex"

	mdefs "github.com/MadHive/MadNet/application/objs/capn"
	"github.com/MadHive/MadNet/application/objs/valuestore"
	capnp "zombiezen.com/go/capnproto2"
)

// ValueStore stores value in a UTXO
type ValueStore struct {
	VSPreImage *VSPreImage `json:"VSPreImage"`
	TxHash     string      `json:"TxHash"`
}

// MarshalBinary takes the ValueStore object and returns the canonical
// byte slice
func (b *ValueStore) MarshalBinary() ([]byte, error) {
	bc, err := b.MarshalCapn(nil)
	if err != nil {
		return nil, err
	}
	return valuestore.Marshal(bc)
}

// MarshalCapn marshals the object into its capnproto definition
func (b *ValueStore) MarshalCapn(seg *capnp.Segment) (mdefs.ValueStore, error) {
	var bc mdefs.ValueStore
	if seg == nil {
		_, seg, err := capnp.NewMessage(capnp.SingleSegment(nil))
		if err != nil {
			return bc, err
		}
		tmp, err := mdefs.NewRootValueStore(seg)
		if err != nil {
			return bc, err
		}
		bc = tmp
	} else {
		tmp, err := mdefs.NewValueStore(seg)
		if err != nil {
			return bc, err
		}
		bc = tmp
	}
	seg = bc.Struct.Segment()
	bt, err := b.VSPreImage.MarshalCapn(seg)
	if err != nil {
		return bc, err
	}
	if err := bc.SetVSPreImage(bt); err != nil {
		return bc, err
	}
	txHash, err := hex.DecodeString(b.TxHash)
	if err != nil {
		return bc, err
	}
	if err := bc.SetTxHash(txHash); err != nil {
		return bc, err
	}
	return bc, nil
}

// PreHash calculates the PreHash of the object
func (b *ValueStore) PreHash() (string, error) {
	return b.VSPreImage.PreHash()
}

// UTXOID calculates the UTXOID of the object
func (b *ValueStore) UTXOID() (string, error) {
	return MakeUTXOID(b.TxHash, b.VSPreImage.TXOutIdx)
}

// TXOutIdx returns the TXOutIdx of the object
func (b *ValueStore) TXOutIdx() uint32 {
	return b.VSPreImage.TXOutIdx
}

func (b *ValueStore) SetTxHash(txHash string) {
	b.TxHash = txHash
}
