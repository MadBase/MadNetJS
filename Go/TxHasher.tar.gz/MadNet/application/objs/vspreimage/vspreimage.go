package vspreimage

import (
	"errors"

	mdefs "github.com/MadHive/MadNet/application/objs/capn"
	capnp "zombiezen.com/go/capnproto2"
)

// Marshal will marshal a VSPreImage object.
func Marshal(v mdefs.VSPreImage) ([]byte, error) {
	raw, err := capnp.Canonicalize(v.Struct)
	if err != nil {
		return nil, err
	}
	out := make([]byte, len(raw))
	copy(out, raw)
	return out, nil
}

// Unmarshal will unmarshal the VSPreImage object.
func Unmarshal(data []byte) (mdefs.VSPreImage, error) {
	var err error
	fn := func() (mdefs.VSPreImage, error) {
		defer func() {
			if r := recover(); r != nil {
				err = errors.New("bad serialization")
			}
		}()
		dataCopy := make([]byte, len(data))
		copy(dataCopy, data)
		msg := &capnp.Message{Arena: capnp.SingleSegment(dataCopy)}
		obj, tmp := mdefs.ReadRootVSPreImage(msg)
		err = tmp
		return obj, err
	}
	obj, err := fn()
	if err != nil {
		return mdefs.VSPreImage{}, err
	}
	return obj, nil
}
