package constants

import "errors"

var (
	// ErrInvalidCurveSpec occurs when we are not using either
	// CurveSecp256k1 or CurveBN256Eth
	ErrInvalidCurveSpec error = errors.New("CurveSpec not defined")

	// ErrInvalidHashLen occurs when the byte slice is not 32 bytes
	ErrInvalidHashLen error = errors.New("Hash length is not 32 bytes")

	// ErrInvalidAccountLen occurs when the byte slice is not 20 bytes
	ErrInvalidAccountLen error = errors.New("Account length is not 20 bytes")

	// ErrInvalidSigLen occurs when the signature is not the correct length
	ErrInvalidSigLen error = errors.New("Invalid signature length")
)
