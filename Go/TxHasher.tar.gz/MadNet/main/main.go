package main

import (
	"encoding/hex"
	"encoding/json"

	"github.com/MadHive/MadNet/application/objs"
	"github.com/gopherjs/gopherjs/js"
	"github.com/miratronix/jopher"
)

func main() {
	//_ = &objs.Tx{}
	js.Module.Get("exports").Set("TxHasher", jopher.Promisify(TxHasher))
	/*
		tx, err := TxHasher(`{"Vin":[{"Signature":"C0FFEE","TXInLinker":{"TxHash":"C0FFEE","TXInPreImage":{"ChainID":42,"ConsumedTxIdx":1,"ConsumedTxHash":"bebccb46480210eda593dd4991d9f024765cb7dc70008e21975180a405da41cf"}}}],"Vout":[{"ValueStore":{"TxHash":"C0FFEE","VSPreImage":{"ChainID":42,"Value":300,"TXOutIdx":0,"Owner":"0101546f99f244b7b58b855330ae0e2bc1b30b41302f"}}},{"ValueStore":{"TxHash":"C0FFEE","VSPreImage":{"ChainID":42,"Value":300,"TXOutIdx":1,"Owner":"0101c0beb3daff9e36ceefbe5fc74ebf4fb0ab49b145"}}},{"ValueStore":{"TxHash":"C0FFEE","VSPreImage":{"ChainID":42,"Value":1122,"TXOutIdx":2,"Owner":"0101546f99f244b7b58b855330ae0e2bc1b30b41302f"}}}]}`)
		if err != nil {
			panic(err)
		}
		fmt.Println(tx)
	*/
}

func TxHasher(s string) (string, error) {
	tx := &objs.Tx{}
	err := json.Unmarshal([]byte(s), tx)
	if err != nil {
		return "", err
	}

	err = tx.SetTxHash()
	if err != nil {
		return "", err
	}
	for _, v := range *tx.Vin {
		preHash, err := v.SignValue()
		if err != nil {
			return "", err
		}
		v.Signature = hex.EncodeToString(preHash)
	}
	for _, v := range *tx.Vout {
		switch {
		case v.HasDataStore():
			preHash, err := v.DataStore.DSLinker.MarshalBinary()
			if err != nil {
				return "", err
			}
			v.DataStore.Signature = hex.EncodeToString(preHash)
		default:
			// do nothing
		}
	}
	sb, err := json.Marshal(tx)
	if err != nil {
		return "", err
	}
	return string(sb), nil

}
