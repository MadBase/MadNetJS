package sorter

import (
	"errors"
	"math/big"
	"sort"
)

// todo move to package level common

type kvs struct {
	keys   [][]byte
	values [][]byte
}

func (s kvs) Len() int {
	return len(s.keys)
}
func (s kvs) Swap(i, j int) {
	s.keys[i], s.keys[j] = s.keys[j], s.keys[i]
	s.values[i], s.values[j] = s.values[j], s.values[i]
}
func (s kvs) Less(i, j int) bool {
	kv1 := new(big.Int).SetBytes(s.keys[i])
	kv2 := new(big.Int).SetBytes(s.keys[j])
	cmp := kv1.Cmp(kv2)
	if cmp <= 0 {
		return true
	}
	return false
}

// SortKVs allows a pair of slices, one containing keys and one containin
// values to be sorted by treating each key as a big.Int and preserving the
// relationship between keys and values during the sort.
func SortKVs(keys [][]byte, values [][]byte) error {
	if len(keys) != len(values) {
		return errors.New("length mismatch")
	}
	kVs := kvs{keys: keys, values: values}
	sort.Sort(kVs)
	return nil
}
