package utils

import (
	"crypto/rand"

	"github.com/MadHive/MadNet/constants"
	"github.com/MadHive/MadNet/errorz"
)

// ForceSliceToLength will return a byte slice of size length.
// It will left pad a byte slice to the specified number of zeros if the
// slice is not long enough. If the slice is too long, it will return the
// right-most bytes of the slice.
func ForceSliceToLength(inSlice []byte, length int) []byte {
	if len(inSlice) > length {
		return CopySlice(inSlice[len(inSlice)-length:])
	}
	outSlice := make([]byte, length-len(inSlice))
	outSlice = append(outSlice, CopySlice(inSlice)...)
	return outSlice
}

// ValidateHash checks whether or not hsh has the correct length
func ValidateHash(hsh []byte) error {
	if len(hsh) != constants.HashLen {
		return errorz.ErrInvalid{}.New("the length of the hash is incorrect")
	}
	return nil
}

// RandomBytes will return a byte slice of num random bytes using crypto rand
func RandomBytes(num int) ([]byte, error) {
	b := make([]byte, num)
	_, err := rand.Read(b)
	if err != nil {
		return nil, err
	}
	return b, nil
}
