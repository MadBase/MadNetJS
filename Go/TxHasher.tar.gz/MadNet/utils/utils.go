package utils

import "github.com/MadHive/MadNet/constants"

// PadZeros will left pad a byte slice to the specified number of zeros.
func PadZeros(inSlice []byte, length int) []byte {
	outSlice := make([]byte, length-len(inSlice))
	outSlice = append(outSlice, inSlice...)
	return outSlice
}

// CopySlice returns a copy of a passed byte slice.
func CopySlice(v []byte) []byte {
	out := make([]byte, len(v))
	copy(out, v)
	return out
}

// Epoch returns the epoch for the corresponding height.
func Epoch(height uint32) uint32 {
	return ((height / constants.EpochLength) + 1)
}
